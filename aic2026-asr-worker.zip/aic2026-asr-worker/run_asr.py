"""
Chạy ASR trên audio tách từ video, xuất transcript thống nhất:
data/processed/transcripts/{video_id}.json -> [{"start":.., "end":.., "text":..}]
Xem quy ước format tại docs/pipeline.md

3 engine, chọn qua config.yaml -> asr.engine:
  - "zipformer" (MẶC ĐỊNH): Zipformer tiếng Việt qua sherpa-onnx (thư viện offline recognizer,
    ONNX runtime, không cần torch). Nhẹ hơn nhiều so với transformers (không cần tải ~2GB
    torch), chạy nhanh trên CPU — hợp với máy cá nhân của team. Cần tải model 1 lần bằng
    download_zipformer_model.sh (hoặc .ps1 trên Windows) trước khi chạy.
  - "transformers" (legacy, chạy tốt trên Kaggle, chỉ cần pip install, không cần biên dịch):
    HF transformers pipeline, model wav2vec2-base-vietnamese-250h (primary) /
    whisper-small (fallback), chia audio theo chunk_length_s cố định. Mỗi đoạn được
    gọi độc lập với pipeline() -> không giữ ngữ cảnh câu trước giữa các đoạn. Lưu ý: cần
    torch/torchaudio/transformers (xem requirements.txt) — bản transformers mới có thể yêu
    cầu torch mới hơn máy đang có, xem README.md mục lỗi "NameError: name 'torch' is not defined".
  - "whisper_cpp" (chạy trên máy có sẵn whisper.cpp, vd. máy local hoặc GPU thuê):
    whisper.cpp CLI (whisper-cli) + model ggml (vd. ggml-small.bin). Dùng -mc 0
    (max-context=0) để mỗi đoạn audio whisper.cpp tự chia được decode độc lập,
    giảm lặp câu/hallucination khi audio dài — theo cách nhóm đã benchmark trong
    final/report.md (script final/extract_audio_transcript.py). Xuất kèm
    .srt/.vtt/.csv/.txt bên cạnh .json (để xem lại nhanh hoặc làm phụ đề), nhưng
    file transcript thống nhất đọc bởi phần index vẫn luôn là .json nói trên.
    Nếu không tìm thấy binary whisper-cli -> tự động chuyển sang engine "zipformer"
    (đảm bảo pipeline vẫn chạy được dù config để whisper_cpp).

Dùng: python run_asr.py --video data/raw/xxx.mp4

Bản này tách riêng từ aic2026-project/indexing/audio_asr/run_asr.py để chạy độc lập trên máy
từng thành viên team (xem README.md ở thư mục này) — output CÙNG SCHEMA với repo chính
(data/processed/transcripts/{video_id}.json) nên gộp thẳng vào aic2026-project/data/processed/
được, không cần chuyển đổi định dạng gì thêm.

Lưu ý hiệu năng: mỗi lần gọi --video sẽ NẠP LẠI model ASR từ đầu (đúng hành vi gốc của repo
chính — scripts/run_indexing_pipeline.py cũng gọi subprocess riêng cho từng video) — không phải
lỗi, nhưng vì vậy chạy song song nhiều video cùng lúc sẽ tốn RAM hơn hẳn bước keyframe (mỗi
tiến trình song song tự nạp 1 bản model riêng). Xem asr_parallel.sh — mặc định chỉ chạy 2 video
song song (thấp hơn nhiều so với extract_parallel.sh của bước keyframe). Riêng web_app.py (Web
UI) cache lại model giữa các lần request thay vì nạp lại mỗi lần — xem docstring ở đó.
"""
import argparse
import json
import shutil
import subprocess
import wave
from pathlib import Path

import numpy as np
import yaml

from extract_audio import extract_audio


def load_config(config_path="config.yaml"):
    with open(config_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


# ---------------------------------------------------------------------------
# Engine 1 (MẶC ĐỊNH): Zipformer tiếng Việt qua sherpa-onnx (ONNX, không cần torch).
# ---------------------------------------------------------------------------

def load_zipformer_recognizer(cfg):
    import sherpa_onnx

    zcfg = cfg["asr"]["zipformer"]
    model_dir = Path(zcfg["model_dir"])
    if not (model_dir / zcfg.get("encoder", "encoder.int8.onnx")).exists():
        raise FileNotFoundError(
            f"Không thấy model Zipformer tại {model_dir}. Chạy 'bash download_zipformer_model.sh' "
            "(hoặc '.\\download_zipformer_model.ps1' trên Windows) để tải model trước."
        )
    recognizer = sherpa_onnx.OfflineRecognizer.from_transducer(
        encoder=str(model_dir / zcfg.get("encoder", "encoder.int8.onnx")),
        decoder=str(model_dir / zcfg.get("decoder", "decoder.onnx")),
        joiner=str(model_dir / zcfg.get("joiner", "joiner.int8.onnx")),
        tokens=str(model_dir / zcfg.get("tokens", "tokens.txt")),
        num_threads=int(zcfg.get("num_threads", 4)),
        decoding_method=zcfg.get("decoding_method", "greedy_search"),
        provider=zcfg.get("provider", "cpu"),
    )
    print(f"[ASR] Dùng engine: zipformer ({model_dir})")
    return recognizer


def _load_wav_mono(wav_path: str):
    """Đọc file WAV 16-bit PCM (đúng định dạng extract_audio.py xuất ra) -> mảng float32
    [-1, 1] mono + sample rate, dùng stdlib `wave` + numpy — không cần torchaudio."""
    with wave.open(str(wav_path), "rb") as f:
        channels = f.getnchannels()
        sample_width = f.getsampwidth()
        sr = f.getframerate()
        frames = f.readframes(f.getnframes())

    if sample_width != 2:
        raise ValueError(f"Cần WAV 16-bit PCM, nhưng sample_width={sample_width} (file: {wav_path})")

    audio = np.frombuffer(frames, dtype=np.int16)
    if channels > 1:
        audio = audio.reshape(-1, channels).mean(axis=1)
    return audio.astype(np.float32) / 32768.0, sr


def transcribe_with_zipformer(wav_path: str, cfg, recognizer=None) -> list:
    # recognizer: cho phép truyền sẵn 1 recognizer đã nạp (vd. web_app.py cache lại giữa các
    # lần request để khỏi nạp lại model mỗi lần) — nếu không truyền, tự nạp mới (dùng bởi
    # run_asr.py CLI / asr_parallel.sh, mỗi tiến trình song song tự nạp riêng 1 bản).
    if recognizer is None:
        recognizer = load_zipformer_recognizer(cfg)

    chunk_length_s = cfg["asr"].get("chunk_length_s", 20)
    waveform, sr = _load_wav_mono(wav_path)
    total_seconds = waveform.shape[0] / sr

    segments = []
    t = 0.0
    while t < total_seconds:
        end = min(t + chunk_length_s, total_seconds)
        chunk = waveform[int(t * sr):int(end * sr)]
        if chunk.size == 0:
            break
        try:
            stream = recognizer.create_stream()
            stream.accept_waveform(sr, chunk)
            recognizer.decode_stream(stream)
            text = stream.result.text.strip().lower()
        except Exception as e:
            text = ""
            print(f"[ASR] Lỗi ở đoạn {t:.1f}-{end:.1f}s: {e}")
        if text:
            segments.append({"start": round(t, 2), "end": round(end, 2), "text": text})
        t = end
    return segments


# ---------------------------------------------------------------------------
# Engine 2 (legacy): HF transformers pipeline — chạy tốt trên Kaggle, pip-installable.
# ---------------------------------------------------------------------------

def load_asr_pipeline(cfg):
    import torch
    from transformers import pipeline

    device = 0 if torch.cuda.is_available() else -1
    primary = cfg["asr"]["primary_model"]
    fallback = cfg["asr"]["fallback_model"]
    try:
        asr = pipeline("automatic-speech-recognition", model=primary, device=device)
        print(f"[ASR] Dùng model chính: {primary}")
        return asr
    except Exception as e:
        print(f"[ASR] Không tải được '{primary}' ({e}). Chuyển sang fallback: {fallback}")
        return pipeline("automatic-speech-recognition", model=fallback, device=device)


def transcribe_with_transformers(wav_path: str, cfg, asr_pipeline=None) -> list:
    import torchaudio

    # asr_pipeline: cho phép truyền sẵn 1 pipeline đã nạp (vd. web_app.py cache lại giữa các
    # lần request để khỏi nạp lại model mỗi lần) — nếu không truyền, giữ đúng hành vi cũ (tự
    # nạp mới mỗi lần gọi, dùng bởi run_asr.py CLI / asr_parallel.sh).
    if asr_pipeline is None:
        asr_pipeline = load_asr_pipeline(cfg)
    chunk_length_s = cfg["asr"]["chunk_length_s"]

    waveform, sr = torchaudio.load(wav_path)
    if sr != 16000:
        waveform = torchaudio.functional.resample(waveform, sr, 16000)
        sr = 16000
    total_seconds = waveform.shape[1] / sr

    segments = []
    t = 0.0
    while t < total_seconds:
        end = min(t + chunk_length_s, total_seconds)
        chunk = waveform[:, int(t * sr):int(end * sr)].squeeze().numpy()
        if chunk.size == 0:
            break
        try:
            result = asr_pipeline({"array": chunk, "sampling_rate": sr})
            text = (result["text"] if isinstance(result, dict) else str(result)).strip().lower()
        except Exception as e:
            text = ""
            print(f"[ASR] Lỗi ở đoạn {t:.1f}-{end:.1f}s: {e}")
        if text:
            segments.append({"start": round(t, 2), "end": round(end, 2), "text": text})
        t = end
    return segments


# ---------------------------------------------------------------------------
# Engine 3 (legacy): whisper.cpp CLI (whisper-cli + model ggml) — máy local / GPU thuê.
# ---------------------------------------------------------------------------

def find_whisper_cli(cfg) -> str:
    configured = cfg["asr"].get("whisper_cpp", {}).get("binary")
    if configured and Path(configured).exists():
        return configured
    return shutil.which("whisper-cli")


def transcribe_with_whisper_cpp(video_id: str, wav_path: str, out_dir: Path, cfg) -> list:
    wcfg = cfg["asr"]["whisper_cpp"]
    binary = find_whisper_cli(cfg)
    model_path = Path(wcfg["model_path"])
    if not model_path.exists():
        raise FileNotFoundError(
            f"Không thấy model ggml: {model_path}. Tải bằng script trong repo whisper.cpp: "
            "models/download-ggml-model.sh small (hoặc tải file .bin tương ứng thủ công)."
        )

    out_dir.mkdir(parents=True, exist_ok=True)
    output_prefix = out_dir / f"{video_id}_whisper_cpp"
    cmd = [binary]
    if not wcfg.get("use_gpu", False):
        cmd.append("--no-gpu")
    cmd += [
        "-m", str(model_path),
        "-f", str(wav_path),
        "-l", wcfg.get("language", "vi"),
        "-mc", str(wcfg.get("max_context", 0)),
        "-oj",                                  # json -> nguồn parse chính, có timestamps
        "-osrt", "-ovtt", "-ocsv", "-otxt",      # bonus: xem lại nhanh / làm phụ đề
        "-of", str(output_prefix),
    ]
    subprocess.run(cmd, check=True)

    json_path = Path(f"{output_prefix}.json")
    raw = json.loads(json_path.read_text(encoding="utf-8"))
    segments = []
    for item in raw.get("transcription", []):
        text = item.get("text", "").strip().lower()
        if not text:
            continue
        offsets = item.get("offsets", {})
        segments.append({
            "start": round(offsets.get("from", 0) / 1000.0, 2),
            "end": round(offsets.get("to", 0) / 1000.0, 2),
            "text": text,
        })
    return segments


# ---------------------------------------------------------------------------

def transcribe_video(video_id: str, wav_path: str, cfg, asr_pipeline=None, zipformer_recognizer=None) -> list:
    # asr_pipeline: chỉ áp dụng cho engine "transformers". zipformer_recognizer: chỉ áp dụng cho
    # engine "zipformer". Cả 2 đều là cơ chế cache model dùng bởi web_app.py (xem docstring
    # transcribe_with_transformers / transcribe_with_zipformer) — không truyền gì thì mỗi lần
    # gọi tự nạp model mới (hành vi CLI / asr_parallel.sh).
    engine = cfg["asr"].get("engine", "zipformer")
    if engine == "zipformer":
        return transcribe_with_zipformer(wav_path, cfg, recognizer=zipformer_recognizer)
    if engine == "whisper_cpp":
        if find_whisper_cli(cfg) is None:
            print("[ASR] engine='whisper_cpp' nhưng không tìm thấy binary whisper-cli -> chuyển sang 'zipformer'.")
            return transcribe_with_zipformer(wav_path, cfg, recognizer=zipformer_recognizer)
        raw_dir = Path(cfg["paths"]["transcripts"]) / "_whisper_cpp_raw"
        print("[ASR] Dùng engine: whisper_cpp")
        return transcribe_with_whisper_cpp(video_id, wav_path, raw_dir, cfg)
    return transcribe_with_transformers(wav_path, cfg, asr_pipeline=asr_pipeline)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config.yaml")
    parser.add_argument("--video", required=True, help="Đường dẫn video gốc")
    args = parser.parse_args()

    cfg = load_config(args.config)
    wav_path = extract_audio(args.video, out_dir="data/processed/_audio_tmp")

    video_id = Path(args.video).stem
    segments = transcribe_video(video_id, wav_path, cfg)

    out_dir = Path(cfg["paths"]["transcripts"])
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"{video_id}.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(segments, f, ensure_ascii=False, indent=2)

    print(f"[{video_id}] {len(segments)} đoạn transcript -> {out_path}")


if __name__ == "__main__":
    main()
