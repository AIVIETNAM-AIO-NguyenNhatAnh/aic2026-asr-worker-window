# download_zipformer_model.ps1 - Ban Windows: tai model Zipformer tieng Viet (sherpa-onnx) mac
# dinh dung boi config.yaml (engine "zipformer"). Tu bo qua neu model da co san.

$ErrorActionPreference = "Stop"
$ScriptDir = $PSScriptRoot

$ModelName = "sherpa-onnx-zipformer-vi-30M-int8-2026-02-09"
$ModelDir = Join-Path $ScriptDir "models\$ModelName"
$Archive = Join-Path $ScriptDir "models\$ModelName.tar.bz2"
$Url = "https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/$ModelName.tar.bz2"

if (Test-Path (Join-Path $ModelDir "encoder.int8.onnx")) {
  Write-Host "[download_zipformer_model.ps1] Model da co san: $ModelDir"
  exit 0
}

New-Item -ItemType Directory -Force -Path (Join-Path $ScriptDir "models") | Out-Null

Write-Host "[download_zipformer_model.ps1] Dang tai $ModelName (vai tram MB, can mang on dinh) ..."
curl.exe -L --retry 5 --retry-delay 3 -o $Archive $Url

Write-Host "[download_zipformer_model.ps1] Giai nen ..."
tar -xjf $Archive -C (Join-Path $ScriptDir "models")
Remove-Item -LiteralPath $Archive -Force

Write-Host "[download_zipformer_model.ps1] Xong: $ModelDir"
