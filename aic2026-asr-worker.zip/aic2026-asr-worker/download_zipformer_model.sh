#!/usr/bin/env bash
# Tải model Zipformer tiếng Việt (sherpa-onnx) mặc định dùng bởi config.yaml (engine "zipformer").
# Model ~30M tham số, quantize int8, chạy nhanh trên CPU — huấn luyện trên ~6000 giờ tiếng Việt.
# Tự bỏ qua nếu model đã có sẵn.
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

MODEL_NAME="sherpa-onnx-zipformer-vi-30M-int8-2026-02-09"
MODEL_DIR="$DIR/models/$MODEL_NAME"
ARCHIVE="$DIR/models/$MODEL_NAME.tar.bz2"
URL="https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/$MODEL_NAME.tar.bz2"

if [ -f "$MODEL_DIR/encoder.int8.onnx" ]; then
  echo "[download_zipformer_model.sh] Model đã có sẵn: $MODEL_DIR"
  exit 0
fi

mkdir -p "$DIR/models"

echo "[download_zipformer_model.sh] Đang tải $MODEL_NAME (vài trăm MB, cần mạng ổn định) ..."
curl -L --retry 5 --retry-delay 3 -o "$ARCHIVE" "$URL"

echo "[download_zipformer_model.sh] Giải nén ..."
tar -xjf "$ARCHIVE" -C "$DIR/models"
rm -f "$ARCHIVE"

echo "[download_zipformer_model.sh] Xong: $MODEL_DIR"
